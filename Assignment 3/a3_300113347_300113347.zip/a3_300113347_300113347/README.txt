NAME: Michael Kagnew
ID: 300113347
SECTION: ITI 1121 A
This assignment is a continuation of the last, with the addition of symmetrical boards being removed from the list of boards.
Thus, only unique boards are in the list of boards.