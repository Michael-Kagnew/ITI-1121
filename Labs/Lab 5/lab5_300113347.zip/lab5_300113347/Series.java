public interface Series {

    // implementation
    public double next();
    
}