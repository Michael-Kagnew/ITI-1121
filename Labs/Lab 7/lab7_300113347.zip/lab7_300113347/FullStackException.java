public class FullStackException extends RuntimeException{
	private int capacity;
	public FullStackException(){
	}
}