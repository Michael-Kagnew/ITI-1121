Michael Kagnew
300113347
ITI 1121-A
A game that plays TicTacToe with an interactive environment