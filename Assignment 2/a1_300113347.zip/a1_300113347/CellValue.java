/**
 * An enum class that defines the
 * values <b>Empty</b>,  <b>X</b>
 * and <b>O</b>.
 *
 * @author Guy-Vincent Jourdan, University of Ottawa
 			Michael Kagnew, University of Ottawa
 */

enum CellValue {

	// YOUR CODE HERE
	EMPTY, X, O;
}