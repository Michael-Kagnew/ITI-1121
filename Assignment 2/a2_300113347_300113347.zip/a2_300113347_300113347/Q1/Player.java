// Author: Michael Kagnew
// Student number: 300113347
// Course: ITI 1121-A
// Assignment: 2
// Question 1
public interface Player{
	
	public void play(TicTacToeGame o);
}