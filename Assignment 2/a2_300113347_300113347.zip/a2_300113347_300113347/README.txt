Michael Kagnew
300113347
ITI 1121-A
Two part assignment. Part 1 has the computer play against the human in an alternating fashion, while part 2 provides all number of possible game combinations for each level plyaed.